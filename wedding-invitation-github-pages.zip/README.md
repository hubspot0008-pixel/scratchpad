# Abhishek Weds Ekta — Wedding Invitation

This is a static website prepared for GitHub Pages.

## Publish with GitHub Pages

1. Create a **public** GitHub repository, for example `wedding-invitation`.
2. Upload the contents of this folder to the repository root (not the containing folder).
3. Open **Settings → Pages**.
4. Under **Build and deployment**, choose **Deploy from a branch**.
5. Select branch `main` and folder `/ (root)`, then Save.
6. Wait for the Pages deployment. Your URL will be `https://YOUR-USERNAME.github.io/wedding-invitation/`.

The site is plain HTML/CSS/JavaScript; no build command is required. Keep `index.html`, `music.mp3`, and `ganesha.png` together in the repository root.

## Important

- This package intentionally excludes browser-profile data, temporary test files, screenshots, and duplicate/unused source files from the original ZIP.
- The page loads Google Fonts from Google Fonts, so those fonts require an internet connection.
- Background audio playback may require a visitor to tap the page first due to browser autoplay restrictions.
